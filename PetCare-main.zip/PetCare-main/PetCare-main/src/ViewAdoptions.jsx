import { Footer } from "./Common/Footer"
import { Header } from "./Common/Header"
import { MyAdoptions } from "./MyAdoptions"


export const ViewAdoptions = () => {
  return (
    <>
    <Header />
    <MyAdoptions />
    <Footer />
    </>
  )
}
