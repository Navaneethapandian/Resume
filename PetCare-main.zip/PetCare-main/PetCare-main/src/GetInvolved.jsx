import React from 'react'
import { Header } from './Common/Header'
import { Footer } from './involved'
import { Partner } from './Partner'

export const GetInvolved = () => {
  return (
    <>
    <Header />
    <Partner />
    <Footer />
    
    </>
  )
}
