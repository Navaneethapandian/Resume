import React from 'react'
import { Navbar } from './Navbar'
import { Adopted } from './Adopted'
import { Unadopted } from './Unadopted'
import { Insert } from './Insert'


export const Admin = () => {
  return (
   <>
   
   <Navbar />
    <Insert />
   </>
  )
}
