import { Header } from './Common/Header'
import { Footer } from './Common/Footer'
import { Infor } from './Contact/Infor'


export const ContactUs = () => {
  return (
    <>
       <Header />
       <Infor />
       <Footer />
    
    </>

  )
}
