import React from 'react'
import { Header } from './Common/Header'
import { Adaption } from './Adaption'
import { Footer } from './Common/Footer'

export const Adaption_Verify = () => {
  return (
    <>
    <Header/>
    <Adaption/>
    <Footer />
    </>
  )
}
